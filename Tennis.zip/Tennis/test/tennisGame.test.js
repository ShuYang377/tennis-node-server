// add.test.js
import {TennisGame} from '../lib/TennisGame.js';
import chai from 'chai';

let expect = chai.expect;

const game = new TennisGame('1','2');

describe('tennis game1', () => {
  it('0 - 0', () => {
    expect(game.detwinner()).to.eql('-'); 
  });
  it('15 - 0', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('15 - 15', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('30 - 15', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('40 - 15', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A - 15', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('1'); 
  });
});

describe('tennis game2', () => {
  it('0 - 0', () => {
    game.reset();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('15 - 15', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('30 - 30', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('40 - 40', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A - 40', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 1 - 40', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('1'); 
  });
});

describe('tennis game3', () => {
  it('0 - 0', () => {
    game.reset();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('15 - 15', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('30 - 30', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('40 - 40', () => {
    game.setPlayer1Score();
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A - 40', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A - A', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 1 - A', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 1 - A + 1', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 2 - A + 1', () => {
    game.setPlayer1Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 2 - A + 2', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 2 - A + 3', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('-'); 
  });
  it('A + 2 - A + 4', () => {
    game.setPlayer2Score();
    expect(game.detwinner()).to.eql('2'); 
  });
});