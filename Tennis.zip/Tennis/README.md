first run  - npm install
then run - npm test to test